﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Util.NumberConvert;

namespace Util.UnitTest
{
    [TestClass]
    public class NumToWordTest
    {
        [TestMethod]
        public void ConvertSingleToWord()
        {
            NumberToWord wc = NumberToWord.GetInstance();
            string result = wc.ConvertNumberToWords(1);
            Assert.AreEqual("one", result);
        }

        [TestMethod]
        public void ConvertDoubleToWord()
        {
            NumberToWord wc = NumberToWord.GetInstance();
            string result = wc.ConvertNumberToWords(21);
            Assert.AreEqual("twenty one", result);
        }

        [TestMethod]
        public void ConvertTripleToWord()
        {
            NumberToWord wc = NumberToWord.GetInstance();
            string result = wc.ConvertNumberToWords(105);
            Assert.AreEqual("one hundred and five", result);
        }

        [TestMethod]
        public void ConvertBigToWord()
        {
            NumberToWord wc = NumberToWord.GetInstance();
            string result = wc.ConvertNumberToWords(56945781);
            Assert.AreEqual("fifty six million nine hundred and forty five thousand seven hundred and eighty one", result);
        }
    }
}
