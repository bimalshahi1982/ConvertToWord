﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util.NumberConvert
{
    public class NumberToWord
    {
        static NumberToWord objntw;
        private NumberToWord()
        {

        }

        public static NumberToWord GetInstance()
        {
            if(objntw == null)
            {
                objntw = new NumberToWord();
                return objntw;
            }
            return objntw;
        }

        public string ConvertNumberToWords(int inputNum)
        {
            string strReturn;
            if (inputNum < 0)
                throw new NotSupportedException("negative numbers not supported");
            else if (inputNum == 0)
                strReturn = "zero";
            else if (inputNum < 10)
                strReturn = ConvertDigitToWords(inputNum);
            else if (inputNum < 20)
                strReturn = ConvertTeensToWords(inputNum);
            else if (inputNum < 100)
                strReturn = ConvertHighTensToWords(inputNum);
            else if (inputNum < 1000)
                strReturn = ConvertBigNumberToWords(inputNum, 100, "hundred");
            else if (inputNum < 1000000)
                strReturn = ConvertBigNumberToWords(inputNum, 1000, "thousand");
            else if (inputNum < 1000000000)
                strReturn = ConvertBigNumberToWords(inputNum, 1000000, "million");
            else
                throw new NotSupportedException("Large numbers not supported");

            return strReturn;
        }

        public string ConvertDigitToWords(int inputNum)
        {
            switch (inputNum)
            {
                case 0: return "";
                case 1: return "one";
                case 2: return "two";
                case 3: return "three";
                case 4: return "four";
                case 5: return "five";
                case 6: return "six";
                case 7: return "seven";
                case 8: return "eight";
                case 9: return "nine";
                default:
                    throw new IndexOutOfRangeException($"{inputNum} not a digit");
            }
        }

        public string ConvertTeensToWords(int inputNum)
        {
            switch (inputNum)
            {
                case 10: return "ten";
                case 11: return "eleven";
                case 12: return "twelve";
                case 13: return "thirteen";
                case 14: return "fourteen";
                case 15: return "fifteen";
                case 16: return "sixteen";
                case 17: return "seventeen";
                case 18: return "eighteen";
                case 19: return "nineteen";
                default:
                    throw new IndexOutOfRangeException($"{inputNum} not between 10 and 19");
            }
        }

        //assumes a number between 20 and 99
        public string ConvertHighTensToWords(int inputNum)
        {
            int tensDigit = (int)(Math.Floor((double)inputNum / 10.0));

            string tensStr;
            switch (tensDigit)
            {
                case 2: tensStr = "twenty"; break;
                case 3: tensStr = "thirty"; break;
                case 4: tensStr = "forty"; break;
                case 5: tensStr = "fifty"; break;
                case 6: tensStr = "sixty"; break;
                case 7: tensStr = "seventy"; break;
                case 8: tensStr = "eighty"; break;
                case 9: tensStr = "ninety"; break;
                default:
                    throw new IndexOutOfRangeException($"{inputNum} not between 20-99");
            }

            if (inputNum % 10 == 0) return tensStr;

            string onesStr;
            onesStr = ConvertDigitToWords(inputNum - tensDigit * 10);

            return tensStr + " " + onesStr;
        }

        // Use this to convert any integer bigger than 99
        public string ConvertBigNumberToWords(int inputNum, int baseNum, string baseNumStr)
        {
            // special case: use space to separate portions of the number, unless we are in the hundreds
            string separator;
            separator = (baseNumStr != "hundred") ? " " : " and ";

            // Strategy: translate the first portion of the number, then recursively translate the remaining sections.
            // Step 1: strip off first portion, and convert it to string:
            int bigPart = (int)(Math.Floor((double)inputNum / baseNum));
            string bigPartStr;

            bigPartStr = ConvertNumberToWords(bigPart) + " " + baseNumStr;

            // Step 2: check to see whether we're done:
            if (inputNum % baseNum == 0)
            {
                return bigPartStr;
            }

            // Step 3: concatenate 1st part of string with recursively generated remainder:
            int restOfNumber = inputNum - bigPart * baseNum;
            return bigPartStr + separator + ConvertNumberToWords(restOfNumber);
        }

    }
}
